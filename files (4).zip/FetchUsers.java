import java.sql.*;

public class FetchUsers {

    // Step 2: JDBC connection constants
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        // Step 5: SQL query
        String sqlQuery = "SELECT * FROM users";

        // Steps 3, 4, 6: try-with-resources for Connection, Statement, ResultSet
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sqlQuery)) {

            // Step 7: Loop through results
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String username = resultSet.getString("username");
                String email = resultSet.getString("email");

                System.out.println("User ID: " + id +
                                   ", Username: " + username +
                                   ", Email: " + email);
            }

        } catch (SQLException e) {
            // Step 8: Handle SQLException
            System.err.println("SQL Exception occurred: " + e.getMessage());
            e.printStackTrace();
        }
        // Step 9: Resources are closed automatically
    }
}
